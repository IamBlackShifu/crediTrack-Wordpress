<?php
defined( 'ABSPATH' ) || exit;
if ( ! is_user_logged_in() ) { auth_redirect(); }
if ( ! current_user_can( 'creditrack_access' ) && ! current_user_can( 'manage_options' ) ) { wp_die( esc_html__( 'Access denied.', 'creditrack' ), '', array( 'response' => 403 ) ); }
global $wpdb;
$page = sanitize_key( get_query_var( 'creditrack_page' ) ?: 'dashboard' );
$allowed = array( 'dashboard','clients','loans','payments','reports','notifications','users','audit','settings','backups','profile' ); if ( ! in_array( $page, $allowed, true ) ) { $page = 'dashboard'; }
if ( get_option( 'creditrack_maintenance' ) && ! current_user_can( 'creditrack_manage_backups' ) ) { wp_die( esc_html__( 'CrediTrack is temporarily unavailable for maintenance.', 'creditrack' ), '', array( 'response' => 503 ) ); }
if ( 'profile' !== $page && get_user_meta( get_current_user_id(), 'creditrack_force_password_change', true ) ) { wp_safe_redirect( home_url( '/creditrack/profile/?password_change=required' ) ); exit; }
$settings = get_option( 'creditrack_settings', array() ); $currency = $settings['currency_symbol'] ?? '$';
$base = home_url( '/creditrack/' ); $user = wp_get_current_user();
?><!doctype html><html <?php language_attributes(); ?>><head><meta charset="<?php bloginfo( 'charset' ); ?>"><meta name="viewport" content="width=device-width,initial-scale=1"><?php wp_head(); ?></head><body><div class="ct-layout"><aside class="ct-sidebar"><div class="ct-brand"><?php echo esc_html( $settings['company_name'] ?? 'CrediTrack' ); ?></div><nav class="ct-nav" aria-label="Primary"><?php
$nav = array( 'dashboard'=>'Dashboard','clients'=>'Clients','loans'=>'Loans','payments'=>'Payments','reports'=>'Reports','notifications'=>'Notifications' ); if ( current_user_can( 'creditrack_manage_users' ) ) { $nav['users']='Users'; } if ( current_user_can( 'creditrack_view_audit' ) ) { $nav['audit']='Audit log'; } if ( current_user_can( 'creditrack_manage_settings' ) ) { $nav['settings']='Settings'; } if ( current_user_can( 'creditrack_manage_backups' ) ) { $nav['backups']='Backups'; } $nav['profile']='Profile';
foreach ( $nav as $slug=>$label ) { printf( '<a href="%s"%s>%s</a>', esc_url( $base . $slug . '/' ), $page === $slug ? ' aria-current="page"' : '', esc_html( $label ) ); }
?></nav><div class="ct-product">A product of<br><strong>Infinity Lines of Code</strong></div></aside><main class="ct-main"><header class="ct-header"><button class="ct-mobile-menu" type="button" aria-label="Toggle navigation">Menu</button><?php $unread=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}ct_notifications WHERE user_id=%d AND read_at IS NULL AND dismissed_at IS NULL",get_current_user_id()));?><a class="ct-notification-link" href="<?php echo esc_url($base.'notifications/');?>" aria-label="<?php echo esc_attr($unread.' unread notifications');?>">Notifications <span><?php echo esc_html($unread);?></span></a><span><?php echo esc_html( $user->display_name ); ?> · <a href="<?php echo esc_url( wp_logout_url( home_url() ) ); ?>">Sign out</a></span></header><div class="ct-content"><?php
if ( isset( $_GET['ct_error'] ) ) { echo '<div class="ct-alert error" role="alert">' . esc_html( sanitize_text_field( wp_unslash( $_GET['ct_error'] ) ) ) . '</div>'; }
if ( isset( $_GET['ct_success'] ) ) { echo '<div class="ct-alert" role="status">Changes saved successfully.</div>'; }
$view = get_template_directory() . '/views/' . $page . '.php'; if ( is_readable( $view ) ) { require $view; }
?></div></main></div><?php wp_footer(); ?></body></html>
