<?php
defined( 'ABSPATH' ) || exit;
get_header();
?><main><p><?php esc_html_e( 'CrediTrack is available to authorized users.', 'creditrack' ); ?></p></main><?php get_footer();
