<?php
namespace CrediTrack\Http;

use CrediTrack\Application\Client_Service;
use CrediTrack\Application\Loan_Service;
use CrediTrack\Application\Payment_Service;

final class Portal_Controller {
	public static function register_actions(): void {
		foreach ( array( 'save_client','deactivate_client','create_loan','loan_action','post_payment','save_profile' ) as $action ) { add_action( 'admin_post_creditrack_' . $action, array( self::class, $action ) ); }
	}
	public static function save_client(): void { self::guard( 'creditrack_manage_clients' ); $result = ( new Client_Service() )->save( wp_unslash( $_POST ), absint( $_POST['client_id'] ?? 0 ) ?: null ); self::finish( $result, 'clients' ); }
	public static function deactivate_client(): void { self::guard( 'creditrack_manage_clients' ); $result = ( new Client_Service() )->deactivate( absint( $_POST['client_id'] ?? 0 ) ); self::finish( $result, 'clients' ); }
	public static function create_loan(): void { self::guard( 'creditrack_create_loans' ); $result = ( new Loan_Service() )->create( wp_unslash( $_POST ) ); self::finish( $result, 'loans' ); }
	public static function loan_action(): void { self::guard( 'creditrack_access' ); $result = ( new Loan_Service() )->transition( absint( $_POST['loan_id'] ?? 0 ), sanitize_key( $_POST['loan_action'] ?? '' ), wp_unslash( $_POST ) ); self::finish( $result, 'loans' ); }
	public static function post_payment(): void { self::guard( 'creditrack_record_payments' ); $result = ( new Payment_Service() )->post( wp_unslash( $_POST ) ); self::finish( $result, 'payments' ); }
	public static function save_profile(): void {
		self::guard( 'creditrack_access' ); $user = wp_get_current_user(); $data = array( 'ID' => $user->ID, 'first_name' => sanitize_text_field( $_POST['first_name'] ?? '' ), 'last_name' => sanitize_text_field( $_POST['last_name'] ?? '' ), 'user_email' => sanitize_email( $_POST['email'] ?? '' ) );
		if ( ! empty( $_POST['new_password'] ) ) { if ( ! wp_check_password( (string) ( $_POST['current_password'] ?? '' ), $user->user_pass, $user->ID ) ) { self::finish( new \WP_Error( 'password', 'Current password is incorrect.' ), 'profile' ); } $data['user_pass'] = (string) $_POST['new_password']; }
		self::finish( wp_update_user( $data ), 'profile' );
	}
	private static function guard( string $capability ): void { if ( ! is_user_logged_in() || ! current_user_can( $capability ) ) { wp_die( esc_html__( 'Access denied.', 'creditrack' ), '', array( 'response' => 403 ) ); } check_admin_referer( 'creditrack_action' ); }
	private static function finish( mixed $result, string $page ): never { $args = is_wp_error( $result ) ? array( 'ct_error' => rawurlencode( $result->get_error_message() ) ) : array( 'ct_success' => 1 ); wp_safe_redirect( add_query_arg( $args, home_url( '/creditrack/' . $page . '/' ) ) ); exit; }
}
