<?php
defined( 'ABSPATH' ) || exit;
if ( is_user_logged_in() ) {
	wp_safe_redirect( home_url( '/creditrack/dashboard/' ) );
	exit;
}
get_header();
?><main style="max-width:680px;margin:10vh auto;padding:32px;text-align:center">
	<h1><?php esc_html_e( 'CrediTrack', 'creditrack' ); ?></h1>
	<p><?php esc_html_e( 'Sign in with an authorized account to access the credit-management portal.', 'creditrack' ); ?></p>
	<p><a class="ct-button" href="<?php echo esc_url( wp_login_url( home_url( '/creditrack/dashboard/' ) ) ); ?>"><?php esc_html_e( 'Sign in to CrediTrack', 'creditrack' ); ?></a></p>
</main><?php get_footer();
