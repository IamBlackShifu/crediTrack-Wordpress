<?php
defined( 'ABSPATH' ) || exit;
add_action( 'after_setup_theme', static function (): void { add_theme_support( 'title-tag' ); } );
add_action( 'wp_enqueue_scripts', static function (): void { if ( get_query_var( 'creditrack_portal' ) ) { wp_enqueue_style( 'creditrack-portal', get_stylesheet_uri(), array(), wp_get_theme()->get( 'Version' ) ); wp_enqueue_script( 'creditrack-portal', get_template_directory_uri() . '/assets/portal.js', array(), wp_get_theme()->get( 'Version' ), true ); } } );
add_action( 'init', static function (): void { add_rewrite_rule( '^creditrack/?([^/]*)/?$', 'index.php?creditrack_portal=1&creditrack_page=$matches[1]', 'top' ); } );
add_filter( 'query_vars', static function ( array $vars ): array { $vars[] = 'creditrack_portal'; $vars[] = 'creditrack_page'; return $vars; } );
add_filter( 'template_include', static function ( string $template ): string { return get_query_var( 'creditrack_portal' ) ? get_template_directory() . '/portal.php' : $template; } );
add_action( 'after_switch_theme', 'flush_rewrite_rules' );
