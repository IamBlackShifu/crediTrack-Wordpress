<?php
namespace CrediTrack\Security;

use CrediTrack\Infrastructure\Audit;
use WP_Error;
use WP_User;

final class Authentication {
	public static function block_inactive( $user, string $username, string $password ) {
		if ( $user instanceof WP_User && '0' === (string) get_user_meta( $user->ID, 'creditrack_active', true ) ) {
			return new WP_Error( 'invalid_login', __( 'The supplied credentials could not be accepted.', 'creditrack' ) );
		}
		return $user;
	}
	public static function record_login( string $login, WP_User $user ): void {
		update_user_meta( $user->ID, 'creditrack_last_login', gmdate( 'Y-m-d H:i:s' ) );
		Audit::record( 'user', $user->ID, 'login', array(), array(), 'Successful login' );
	}
	public static function protect_wp_admin(): void {
		if ( is_admin() && ! wp_doing_ajax() && current_user_can( 'creditrack_access' ) && ! current_user_can( 'manage_options' ) ) { wp_safe_redirect( home_url( '/creditrack/' ) ); exit; }
	}
	public static function show_admin_bar( bool $show ): bool { return current_user_can( 'manage_options' ) ? $show : false; }
}
