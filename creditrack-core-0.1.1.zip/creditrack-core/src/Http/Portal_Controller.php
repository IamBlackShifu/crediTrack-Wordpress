<?php
namespace CrediTrack\Http;

use CrediTrack\Application\Client_Service;
use CrediTrack\Application\Loan_Service;
use CrediTrack\Application\Payment_Service;

final class Portal_Controller {
	public static function register_actions(): void {
		foreach ( array( 'save_client','deactivate_client','create_loan','loan_action','post_payment','save_profile','save_settings' ) as $action ) { add_action( 'admin_post_creditrack_' . $action, array( self::class, $action ) ); }
	}
	public static function save_client(): void { self::guard( 'creditrack_manage_clients' ); $result = ( new Client_Service() )->save( wp_unslash( $_POST ), absint( $_POST['client_id'] ?? 0 ) ?: null ); self::finish( $result, 'clients' ); }
	public static function deactivate_client(): void { self::guard( 'creditrack_manage_clients' ); $result = ( new Client_Service() )->deactivate( absint( $_POST['client_id'] ?? 0 ) ); self::finish( $result, 'clients' ); }
	public static function create_loan(): void { self::guard( 'creditrack_create_loans' ); $result = ( new Loan_Service() )->create( wp_unslash( $_POST ) ); self::finish( $result, 'loans' ); }
	public static function loan_action(): void { self::guard( 'creditrack_access' ); $result = ( new Loan_Service() )->transition( absint( $_POST['loan_id'] ?? 0 ), sanitize_key( $_POST['loan_action'] ?? '' ), wp_unslash( $_POST ) ); self::finish( $result, 'loans' ); }
	public static function post_payment(): void { self::guard( 'creditrack_record_payments' ); $result = ( new Payment_Service() )->post( wp_unslash( $_POST ) ); self::finish( $result, 'payments' ); }
	public static function save_profile(): void {
		self::guard( 'creditrack_access' ); $user = wp_get_current_user(); $data = array( 'ID' => $user->ID, 'first_name' => sanitize_text_field( $_POST['first_name'] ?? '' ), 'last_name' => sanitize_text_field( $_POST['last_name'] ?? '' ), 'user_email' => sanitize_email( $_POST['email'] ?? '' ) );
		if ( ! empty( $_POST['new_password'] ) ) { if ( ! wp_check_password( (string) ( $_POST['current_password'] ?? '' ), $user->user_pass, $user->ID ) ) { self::finish( new \WP_Error( 'password', 'Current password is incorrect.' ), 'profile' ); } $data['user_pass'] = (string) $_POST['new_password']; }
		self::finish( wp_update_user( $data ), 'profile' );
	}
	public static function save_settings(): void {
		self::guard( 'creditrack_manage_settings' );
		$input = wp_unslash( $_POST );
		$required = array( 'company_name', 'currency_code', 'currency_symbol', 'date_format' );
		foreach ( $required as $field ) {
			if ( '' === trim( (string) ( $input[ $field ] ?? '' ) ) ) {
				self::finish( new \WP_Error( 'validation', ucfirst( str_replace( '_', ' ', $field ) ) . ' is required.' ), 'settings' );
			}
		}
		$interest_type = sanitize_text_field( $input['default_interest_type'] ?? 'Flat' );
		if ( ! in_array( $interest_type, array( 'Flat', 'Monthly', 'Quarterly', 'Annual' ), true ) ) {
			self::finish( new \WP_Error( 'validation', 'Select a valid default interest type.' ), 'settings' );
		}
		$rate = (string) ( $input['default_interest_rate'] ?? '' );
		if ( ! is_numeric( $rate ) || (float) $rate < 0 || (float) $rate > 1000 ) {
			self::finish( new \WP_Error( 'validation', 'Default interest rate must be between 0 and 1000.' ), 'settings' );
		}
		$timezone = sanitize_text_field( $input['timezone'] ?? 'UTC' );
		if ( ! in_array( $timezone, timezone_identifiers_list(), true ) ) {
			self::finish( new \WP_Error( 'validation', 'Select a valid timezone.' ), 'settings' );
		}
		$old = get_option( 'creditrack_settings', array() );
		$new = array(
			'company_name' => sanitize_text_field( $input['company_name'] ),
			'company_address' => sanitize_textarea_field( $input['company_address'] ?? '' ),
			'company_phone' => sanitize_text_field( $input['company_phone'] ?? '' ),
			'company_email' => sanitize_email( $input['company_email'] ?? '' ),
			'currency_code' => strtoupper( substr( sanitize_text_field( $input['currency_code'] ), 0, 3 ) ),
			'currency_symbol' => sanitize_text_field( $input['currency_symbol'] ),
			'currency_precision' => 2,
			'timezone' => $timezone,
			'date_format' => sanitize_text_field( $input['date_format'] ),
			'default_interest_rate' => number_format( (float) $rate, 4, '.', '' ),
			'default_term' => min( 600, max( 1, absint( $input['default_term'] ?? 12 ) ) ),
			'default_interest_type' => $interest_type,
			'grace_days' => min( 365, absint( $input['grace_days'] ?? 0 ) ),
			'notifications_enabled' => ! empty( $input['notifications_enabled'] ),
			'reminder_days' => min( 365, max( 1, absint( $input['reminder_days'] ?? 7 ) ) ),
			'officer_can_approve' => ! empty( $input['officer_can_approve'] ),
			'officer_can_disburse' => ! empty( $input['officer_can_disburse'] ),
			'max_upload_mb' => min( 50, max( 1, absint( $input['max_upload_mb'] ?? 5 ) ) ),
			'backup_retention_days' => min( 3650, max( 1, absint( $input['backup_retention_days'] ?? 30 ) ) ),
			'updated_by' => get_current_user_id(),
			'updated_at' => gmdate( 'Y-m-d H:i:s' ),
		);
		update_option( 'creditrack_settings', $new, false );
		\CrediTrack\Infrastructure\Audit::record( 'settings', null, 'update', $old, $new, 'CrediTrack settings updated' );
		self::finish( true, 'settings' );
	}
	private static function guard( string $capability ): void { if ( ! is_user_logged_in() || ! current_user_can( $capability ) ) { wp_die( esc_html__( 'Access denied.', 'creditrack' ), '', array( 'response' => 403 ) ); } check_admin_referer( 'creditrack_action' ); }
	private static function finish( mixed $result, string $page ): never { $args = is_wp_error( $result ) ? array( 'ct_error' => rawurlencode( $result->get_error_message() ) ) : array( 'ct_success' => 1 ); wp_safe_redirect( add_query_arg( $args, home_url( '/creditrack/' . $page . '/' ) ) ); exit; }
}
